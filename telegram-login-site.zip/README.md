# Telegram Login website

## Nimalar bor
- Telegram orqali foydalanuvchining o‘zi rozilik bildirgan holda kirishi
- Ism, familiya va username
- SQLite ma’lumotlar bazasida foydalanuvchilar ro‘yxati
- Bir nechta administrator (Telegram numeric ID ro‘yxati orqali)
- Admin panelida foydalanuvchilar soni va ro‘yxati
- Server tomonida Telegram imzosini tekshirish; muddati o‘tgan login ma’lumoti rad etiladi

## Ishga tushirish
1. Kompyuter yoki Node.js hostingda Node.js 20+ o‘rnating.
2. `npm install`
3. `.env.example` faylidan `.env` nusxa oling.
4. @BotFather orqali bot yarating yoki o‘zingiz boshqaradigan botdan foydalaning.
5. BotFather’da `/setdomain` buyrug‘i bilan saytingizning HTTPS domenini ulang.
6. `.env` ichida `BOT_TOKEN`, `BOT_USERNAME`, `SITE_DOMAIN`, `SESSION_SECRET` va `ADMIN_IDS` ni kiriting.
   - `BOT_USERNAME` — `@` belgisiz bot username.
   - `ADMIN_IDS` — administratorlarning Telegram raqamli ID’lari, vergul bilan ajratiladi.
   - `SITE_DOMAIN` — BotFather’da tasdiqlangan domen.
7. `npm start` buyrug‘ini ishga tushiring.

## Muhim xavfsizlik
- Bot tokenini hech qachon HTML/JavaScript ichiga yozmang, chatga yubormang yoki GitHub’ga joylamang. U faqat serverdagi `.env` faylida turishi kerak.
- `.env` va `data/` papkasini ommaga ochmang.
- Internetga chiqarishda HTTPS ishlating va `NODE_ENV=production` qo‘ying.
- `SESSION_SECRET` uchun uzun, tasodifiy maxfiy qiymat ishlating.
- Administratorlar ro‘yxatiga faqat ishonchli odamlarning Telegram ID’larini kiriting.
- Bu boshlang‘ich loyiha: ommaviy ishlab chiqarishdan oldin zaxira nusxa, monitoring va ma’lumotlarni saqlash siyosatini sozlang.

## Eslatma
Telegram Login tugmasi ishlashi uchun bot domeni BotFather’da sozlangan bo‘lishi kerak. Bu loyiha SMS-kod yoki Telegram parolini so‘ramaydi.
