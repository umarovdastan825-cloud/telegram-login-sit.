const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const Database = require("better-sqlite3");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const crypto = require("crypto");
const path = require("path");
require("dotenv").config();

const { BOT_TOKEN, SITE_DOMAIN, SESSION_SECRET } = process.env;
const ADMIN_IDS = new Set((process.env.ADMIN_IDS || "").split(",").map(x => x.trim()).filter(Boolean));

if (!BOT_TOKEN || !SITE_DOMAIN || !SESSION_SECRET) {
  console.error("Set BOT_TOKEN, SITE_DOMAIN and SESSION_SECRET in .env");
  process.exit(1);
}
if (SESSION_SECRET.length < 32) {
  console.error("SESSION_SECRET must be at least 32 characters.");
  process.exit(1);
}

const app = express();
require("fs").mkdirSync("data", { recursive: true });
const db = new Database("data/users.db");
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    telegram_id TEXT PRIMARY KEY,
    first_name TEXT NOT NULL,
    last_name TEXT DEFAULT '',
    username TEXT DEFAULT '',
    photo_url TEXT DEFAULT '',
    created_at TEXT NOT NULL
  )
`);
const saveUser = db.prepare(`
  INSERT INTO users (telegram_id, first_name, last_name, username, photo_url, created_at)
  VALUES (@id, @first_name, @last_name, @username, @photo_url, @created_at)
  ON CONFLICT(telegram_id) DO UPDATE SET
    first_name=excluded.first_name, last_name=excluded.last_name,
    username=excluded.username, photo_url=excluded.photo_url
`);
const listUsers = db.prepare(`SELECT telegram_id, first_name, last_name, username, created_at FROM users ORDER BY created_at DESC`);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "20kb" }));
app.use(session({
  store: new SQLiteStore({ db: "sessions.db", dir: "./data" }),
  name: "site.sid",
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 7 * 24 * 60 * 60 * 1000
  }
}));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 60, standardHeaders: true, legacyHeaders: false }));

function verifyTelegramLogin(payload) {
  if (!payload || typeof payload !== "object") return false;
  const { hash, ...data } = payload;
  if (typeof hash !== "string") return false;

  const authDate = Number(data.auth_date);
  const now = Math.floor(Date.now() / 1000);
  if (!Number.isFinite(authDate) || authDate > now + 30 || now - authDate > 600) return false;

  const checkString = Object.keys(data).sort()
    .map(key => `${key}=${data[key]}`).join("\n");
  const secretKey = crypto.createHash("sha256").update(BOT_TOKEN).digest();
  const expected = crypto.createHmac("sha256", secretKey).update(checkString).digest("hex");

  const a = Buffer.from(expected, "hex");
  const b = Buffer.from(hash, "hex");
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function requireLogin(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "Avval Telegram orqali kiring." });
  next();
}
function requireAdmin(req, res, next) {
  if (!req.session.user || !ADMIN_IDS.has(String(req.session.user.id))) {
    return res.status(403).json({ error: "Bu bo‘lim faqat administratorlar uchun." });
  }
  next();
}

app.post("/api/auth/telegram", (req, res) => {
  const user = req.body;
  if (!verifyTelegramLogin(user)) return res.status(401).json({ error: "Telegram tasdiqlashi yaroqsiz yoki muddati tugagan." });
  if (!user.id || !user.first_name) return res.status(400).json({ error: "Telegram profil ma’lumoti yetarli emas." });

  const safeUser = {
    id: String(user.id),
    first_name: String(user.first_name).slice(0, 100),
    last_name: String(user.last_name || "").slice(0, 100),
    username: String(user.username || "").slice(0, 100),
    photo_url: String(user.photo_url || "").slice(0, 500)
  };
  saveUser.run({ ...safeUser, created_at: new Date().toISOString() });
  req.session.user = safeUser;
  res.json({ ok: true, user: safeUser, isAdmin: ADMIN_IDS.has(safeUser.id) });
});

app.get("/api/me", (req, res) => {
  res.json({ user: req.session.user || null, isAdmin: !!req.session.user && ADMIN_IDS.has(String(req.session.user.id)) });
});
app.post("/api/logout", requireLogin, (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});
app.get("/api/admin/users", requireAdmin, (req, res) => {
  res.json({ users: listUsers.all(), total: db.prepare("SELECT COUNT(*) AS n FROM users").get().n });
});
app.get("/api/admin/admins", requireAdmin, (req, res) => {
  res.json({ admins: [...ADMIN_IDS] });
});

app.get("/config.js", (req, res) => {
  res.type("application/javascript").send(`window.TELEGRAM_BOT_USERNAME = ${JSON.stringify(process.env.BOT_USERNAME || "")};`);
});
app.use(express.static(path.join(__dirname, "public")));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Website running on port ${port}`));
